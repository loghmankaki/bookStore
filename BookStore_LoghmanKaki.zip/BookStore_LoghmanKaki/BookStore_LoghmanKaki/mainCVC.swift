//
//  mainCVC.swift
//  BookStore_LoghmanKaki
//
//  Created by mac on 12/31/20.
//

import UIKit


class mainCVC: UICollectionViewController,UICollectionViewDelegateFlowLayout {
    
    var Books = [bookStore]()
    var FavBooks = [bookStore]()
    
    var isShowFav: Bool = false
    
    let booKstoreData = getdata()

    private let reuseIdentifier = "Cell"
    private var selectedIndex: IndexPath?

    @IBOutlet weak var showFavOnOff: UIBarButtonItem!
    

    
    
    
    // MARK: - viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        //load saved favorite books
        favoriteBooks = load()


        
        //load 10 first books from server
        booKstoreData.GetDataFromBookStoreAPI(maxResults: 10, startIndex: 0, completionBlock: {cat in
            self.Books = cat
            DispatchQueue.main.async {
                self.collectionView.reloadData()
           }
       })
    }
    
    
    // MARK: - show/hide favorite books
    @IBAction func showFav(_ sender: Any) {
        if !isShowFav {
            FavBooks.removeAll()
            showFavOnOff.title = "Show All"
            isShowFav = true
                        
            FavBooks = load()

        }else{
            showFavOnOff.title = "Show Fav."
            isShowFav = false
        }
        collectionView.reloadData()

    }
    
   
    // MARK: UICollection View Delegates
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        if isShowFav{
            return FavBooks.count
        }else{
            return Books.count
        }
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as? mainCVCell else {
            return UICollectionViewCell()
        }
        var url: URL!
        if isShowFav{
            url = URL(string: FavBooks[indexPath.row].Thumbnail)
        }else{
            url = URL(string: Books[indexPath.row].Thumbnail)
        }
        
        let data = try? Data(contentsOf: url!)
        
        if let imageData = data {
            cell.bookPhoto.image = UIImage(data: imageData)
        }

        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath
        show(selectedBook: Books[indexPath.row], animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var noOfCellsInRow = 2

        if UIDevice.current.userInterfaceIdiom == .pad {
            noOfCellsInRow = 4
        }

        let flowLayout = collectionViewLayout as! UICollectionViewFlowLayout

        let totalSpace = flowLayout.sectionInset.left
            + flowLayout.sectionInset.right
            + (flowLayout.minimumInteritemSpacing * CGFloat(noOfCellsInRow - 1))

        let size = Int((collectionView.bounds.width - totalSpace) / CGFloat(noOfCellsInRow))

        return CGSize(width: size, height: size)
    }
    
    override func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let lastElement = Books.count - 1
        if indexPath.row == lastElement {
            updateNextSet()
            // handle your logic here to get more items, add it to dataSource and reload tableview
            }
    }
    // MARK: Functions

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? bookDetailsVC,
            let selectedBook = sender as? bookStore {
            vc.BookID = selectedBook.ID
            vc.BookTitle = selectedBook.Title
            vc.BookAuthor = selectedBook.Authors
            vc.BookDescription = selectedBook.Description
            vc.BuyLink = selectedBook.Buylink
            vc.Thumbnail = selectedBook.Thumbnail
            
        }
    }
    
    func load() -> [bookStore] {
        guard let encodedData = UserDefaults.standard.array(forKey: "favoriteBooks") as? [Data] else {
            return []
        }

        return encodedData.map { try! JSONDecoder().decode(bookStore.self, from: $0) }
    }
    
    private func show(selectedBook: bookStore, animated: Bool) {
        let identifier = "BookDetailsSegue"
        performSegue(withIdentifier: identifier, sender: selectedBook)
    }
    private func updateNextSet(){
        //requests another set of data (10 more items) from the server.
        booKstoreData.GetDataFromBookStoreAPI(maxResults: 10, startIndex: Books.count, completionBlock: {cat in
            self.Books = cat
            DispatchQueue.main.async {
                self.collectionView.reloadData()

            }
       })
    }
 
}
// MARK: extensions

extension UIView {
   func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
  
}
