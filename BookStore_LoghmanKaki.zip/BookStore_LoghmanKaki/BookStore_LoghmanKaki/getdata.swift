//
//  getdata.swift
//  IOSTask
//
//  Created by majid on 8/14/20.
//  Copyright © 2020 NiKa. All rights reserved.
//


import Foundation
class getdata {

    private var Books = [bookStore]()
    
//..............................................................................
    func GetDataFromBookStoreAPI(maxResults: Int, startIndex: Int ,completionBlock:@escaping ([bookStore]) -> ()){

        let URL_SAVE_TEAM = URL(string: "https://www.googleapis.com/books/v1/volumes?q=ios&maxResults=\(maxResults)&startIndex=\(startIndex)")
        let request = NSMutableURLRequest(url: URL_SAVE_TEAM!)
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request as URLRequest){ data, response, error  in
            if error != nil{
                print("error is \(String(describing: error))")
                return;
            }
            self.parseBookStoreData(data: data!)
            completionBlock(self.Books)
        }
        task.resume()
    }

//..............................................................................
     func parseBookStoreData(data: Data){
        do {
            let Data = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as! NSDictionary

            let items:NSArray = Data["items"]! as! NSArray
            for item in items {
                let row:NSDictionary = item as! NSDictionary

                var temp = bookStore()
                
                temp.ID = row["id"]! as! String
                
                let volumeInfo:NSDictionary = row["volumeInfo"]! as! NSDictionary
                temp.Title = volumeInfo["title"]! as! String
                
                if volumeInfo["authors"] != nil{
                    let authorsData:NSArray = (volumeInfo["authors"]! as? NSArray)!
                    var authors = [String]()
                    for m in 0..<authorsData.count {
                        let eachAuthors = authorsData[m] as! String
                        authors.append(eachAuthors)
                    }
                    temp.Authors = "By: " + authors.joined(separator: ", ")

                }
  
                temp.Description = volumeInfo["description"]! as! String
                
                let imageLinks:NSDictionary = volumeInfo["imageLinks"]! as! NSDictionary
                temp.Thumbnail  = imageLinks["thumbnail"] as! String
                
                let saleInfo:NSDictionary = row["saleInfo"]! as! NSDictionary
                temp.isAvailable  = saleInfo["saleability"] as! String
                if temp.isAvailable == "FOR_SALE"{
                    temp.Buylink  = saleInfo["buyLink"] as! String
                }
                
                self.Books.append(temp)
            }
        }
        catch  {
            print(error)
        }
    }
//..............................................................................

}
