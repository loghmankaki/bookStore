//
//  mainCVCell.swift
//  BookStore_LoghmanKaki
//
//  Created by mac on 12/31/20.
//

import UIKit

class mainCVCell: UICollectionViewCell {
    
    @IBOutlet weak var bookPhoto: UIImageView!
}
