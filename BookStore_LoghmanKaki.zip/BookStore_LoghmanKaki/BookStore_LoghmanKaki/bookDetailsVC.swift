//
//  bookDetailsVC.swift
//  BookStore_LoghmanKaki
//
//  Created by mac on 12/31/20.
//

import UIKit


struct Person: Codable {
    var name: String
}

let taylor = Person(name: "Taylor Swift")

class bookDetailsVC: UIViewController {

    @IBOutlet weak var bookTitle: UILabel!
    @IBOutlet weak var authors: UILabel!
    @IBOutlet weak var bookDescription: UITextView!
    @IBOutlet weak var buy: UIButton!
    @IBOutlet weak var isFavorite: UIButton!
    
    var BookID = String()
    var BookTitle = String()
    var BookAuthor = String()
    var BookDescription = String()
    var BuyLink = String()
    var Thumbnail = String()

    
    // MARK: - viewDidLoad

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        buy.roundCorners(corners: [.topLeft], radius: 15)
        isFavorite.roundCorners(corners: [.bottomRight], radius: 24)

        
        
        bookTitle.text = BookTitle
        authors.text = BookAuthor
        bookDescription.text = BookDescription
        
        if BuyLink == ""{
            buy.isEnabled = false
            buy.setTitle("This Book isn't available!", for: .normal)
        }
        
        print(favoriteBooks.count)
        if let i = favoriteBooks.firstIndex(where: { $0.ID == BookID }) {
            print(i)
            isFavorite.setTitle("unfavorite", for: .normal)
        }else{
            isFavorite.setTitle("favorite", for: .normal)
        }

    }
    
    
    // MARK: - buy Btn Action

    @IBAction func buy(_ sender: Any) {
        print(BuyLink)
        if let url = URL(string: BuyLink) {
           if #available(iOS 10.0, *) {
               UIApplication.shared.open(url, options: [:], completionHandler: nil)
           } else {
               // Earlier versions
               if UIApplication.shared.canOpenURL(url as URL) {
                  UIApplication.shared.openURL(url as URL)
               }
           }
        }
    }
    
    // MARK: - favorite Btn Action

    @IBAction func isFavorate(_ sender: Any)  {
        var tempBook = bookStore()
        tempBook.ID = BookID
        tempBook.Title = BookTitle
        tempBook.Description = BookDescription
        tempBook.Authors = BookAuthor
        tempBook.Buylink = BuyLink
        tempBook.Thumbnail = Thumbnail


        if let i = favoriteBooks.firstIndex(where: { $0.ID == BookID }) {
            isFavorite.setTitle("favorite", for: .normal)
            favoriteBooks.remove(at: i)
        }else{
            isFavorite.setTitle("unfavorite", for: .normal)
            favoriteBooks.append(tempBook)
        }
        let data = favoriteBooks.map { try? JSONEncoder().encode($0) }
            UserDefaults.standard.set(data, forKey: "favoriteBooks")
    }
    
}
