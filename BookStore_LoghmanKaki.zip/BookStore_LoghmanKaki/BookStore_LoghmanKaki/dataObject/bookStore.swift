//
//  bookStore.swift
//  BookStore_LoghmanKaki
//
//  Created by mac on 12/30/20.
//

import Foundation
struct bookStore: Codable {
    var ID = String()
    var Thumbnail = String()
    var Title = String()
    var Authors = String()
    var Description = String()
    var isAvailable = String()
    var Buylink = String()
}

var favoriteBooks = [bookStore]()
